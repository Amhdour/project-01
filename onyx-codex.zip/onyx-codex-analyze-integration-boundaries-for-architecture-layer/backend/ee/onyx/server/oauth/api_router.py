from fastapi import APIRouter

router: APIRouter = APIRouter(prefix="/oauth")
