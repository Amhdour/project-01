MODEL_WARM_UP_STRING = "hi " * 512


class GPUStatus:
    CUDA = "cuda"
    MAC_MPS = "mps"
    NONE = "none"
